# TikTok HD Downloader (V4)

Static website with TikTok link preview and a Netlify Function that attempts to expand TikTok short links.

## Deploy
Deploy this repository through Netlify with Git integration. The `netlify/functions/resolve-tiktok.js` function will not run on a plain static drag-and-drop deployment unless Netlify processes the function during a supported build.

## Important limitations
- This project does not extract MP4 files, remove watermarks, bypass privacy settings, or circumvent creator download controls.
- The Download/save action is intentionally the original TikTok post. Use TikTok's Save Video option only when the creator allows it.
- TikTok may block or change redirects, so short-link resolution is not guaranteed.
- Replace the Contact page placeholder with a real contact email before applying for advertising.
