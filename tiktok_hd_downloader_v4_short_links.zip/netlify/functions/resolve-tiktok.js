exports.handler = async (event) => {
  const raw = event.queryStringParameters && event.queryStringParameters.url;
  if (!raw) return { statusCode: 400, body: JSON.stringify({ error: "TikTok URL is required" }) };
  let input;
  try { input = new URL(raw); } catch { return { statusCode: 400, body: JSON.stringify({ error: "Invalid URL" }) }; }
  const allowed = (h) => h === "tiktok.com" || h.endsWith(".tiktok.com");
  if (!allowed(input.hostname)) return { statusCode: 400, body: JSON.stringify({ error: "Only TikTok URLs are allowed" }) };
  try {
    const response = await fetch(input.href, { method: "GET", redirect: "follow", headers: { "User-Agent": "Mozilla/5.0" } });
    const finalUrl = new URL(response.url);
    if (!allowed(finalUrl.hostname)) throw new Error("Redirect left TikTok domain");
    return { statusCode: 200, headers: { "content-type": "application/json", "cache-control": "no-store" }, body: JSON.stringify({ url: finalUrl.href }) };
  } catch (e) {
    return { statusCode: 502, headers: { "content-type": "application/json" }, body: JSON.stringify({ error: "TikTok short link could not be resolved. Try the full video URL." }) };
  }
};
